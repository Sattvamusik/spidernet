#!/bin/bash
echo '🚑 Trauma running'
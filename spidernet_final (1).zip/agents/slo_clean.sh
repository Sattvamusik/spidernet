#!/bin/bash
echo '🧹 SLO Cleaner running'
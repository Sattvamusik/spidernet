#!/bin/bash
echo '👁️ Watchdog running'
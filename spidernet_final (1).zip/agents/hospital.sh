#!/bin/bash
echo '🏥 Hospital running'
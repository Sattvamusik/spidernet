# TODO.md — SpiderNet Tasks

1. Install final ZIP
2. Verify Cockpit

# PROJECTS.md — SpiderNet Universe

- SpiderNet Core
- CineSoul
- Tathata BOS
- SLO

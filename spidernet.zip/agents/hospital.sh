#!/bin/bash
LOG="$HOME/.spidernet/logs/hospital.log"
echo "=== 🩺 Hospital Check $(date) ===" >> "$LOG"

pgrep -f "python.*cockpit.py" >/dev/null && echo "✅ Cockpit running" >> "$LOG" || echo "❌ Cockpit stopped" >> "$LOG"

cpu=$(top -bn1 | awk '/Cpu/ {print 100-$8"%"}')
mem=$(free -m | awk 'NR==2{printf "%.1f%%", $3*100/$2}')
echo "📊 CPU: $cpu | MEM: $mem" >> "$LOG"

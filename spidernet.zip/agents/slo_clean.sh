#!/bin/bash
LOG="$HOME/.spidernet/logs/cleaner.log"
ARCHIVE="$HOME/Desktop/Archived"
mkdir -p "$ARCHIVE/Documents" "$ARCHIVE/Images" "$ARCHIVE/Others"

count=0
for file in "$HOME/Desktop"/*; do
  [ ! -f "$file" ] && continue
  case "$file" in
    *.pdf|*.doc|*.txt) mv "$file" "$ARCHIVE/Documents/" ;;
    *.jpg|*.png)       mv "$file" "$ARCHIVE/Images/" ;;
    *)                 mv "$file" "$ARCHIVE/Others/" ;;
  esac
  ((count++))
done

echo "🧹 Cleaned $count files at $(date)" >> "$LOG"

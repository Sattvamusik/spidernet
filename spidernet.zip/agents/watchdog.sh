#!/bin/bash
LOG="$HOME/.spidernet/logs/watchdog.log"
echo "=== 👁 Watchdog $(date) ===" >> "$LOG"
$HOME/.spidernet/hospital.sh
$HOME/.spidernet/trauma_center.sh
echo "✅ Watchdog cycle complete" >> "$LOG"

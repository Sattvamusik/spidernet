#!/bin/bash
LOG="$HOME/.spidernet/logs/trauma.log"
echo "=== 🚑 Trauma $(date) ===" >> "$LOG"

if ! pgrep -f "python.*cockpit.py" >/dev/null; then
  echo "🔄 Restarting Cockpit..." >> "$LOG"
  nohup python3 "$HOME/.spidernet/cockpit.py" >/dev/null 2>&1 &
fi

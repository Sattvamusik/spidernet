#!/usr/bin/env python3
import sys, os, subprocess
from PyQt5.QtWidgets import QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QLabel, QTextEdit
from PyQt5.QtCore import QTimer, Qt

BASE = os.path.expanduser("~/.spidernet")
LOGS = os.path.join(BASE, "logs")

class Dashboard(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        self.banner = QLabel("🌻 Checking SpiderNet...")
        self.banner.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.banner)

        self.logbox = QTextEdit()
        self.logbox.setReadOnly(True)
        layout.addWidget(self.logbox)
        self.setLayout(layout)
        self.refresh()
        timer = QTimer(self)
        timer.timeout.connect(self.refresh)
        timer.start(10000)

    def refresh(self):
        flag = os.path.join(LOGS, "status.flag")
        if os.path.exists(flag):
            self.banner.setText("✅ SPIDERNET IS ALIVE")
        try:
            with open(os.path.join(LOGS, "hospital.log")) as f:
                self.logbox.setText("".join(f.readlines()[-10:]))
        except: pass

class Cockpit(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🌻 SpiderNet Cockpit")
        tabs = QTabWidget()
        tabs.addTab(Dashboard(), "📊 Dashboard")
        self.setCentralWidget(tabs)

app = QApplication(sys.argv)
win = Cockpit()
win.show()
app.exec_()

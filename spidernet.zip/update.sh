#!/bin/bash
echo "🔄 Updating SpiderNet..."
curl -fsSL https://raw.githubusercontent.com/omvatayan/spidernet/main/install.sh | bash

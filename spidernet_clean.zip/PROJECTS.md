# 📌 SpiderNet Projects

## Active
- SpiderNet Core (Install, Cockpit, Auto-update)
- Hospital, Trauma, Watchdog, Cleaner agents

## Planned
- Archivist Agent (logs all activity + projects)
- Advisory System (auto-suggest improvements into IDEAS.md)
- Self-learning improvements loop

---
✅ Completed projects are ticked as we go.

# 💡 SpiderNet Ideas (Advisory)

- Auto-suggest system improvements daily
- Record every new feature request here
- Connect Archivist agent with Advisory tab in Cockpit

---
(SpiderNet will expand this file automatically as it learns.)
